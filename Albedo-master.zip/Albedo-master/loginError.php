<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page 404</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="row">
        <div class="col-sm-6">
           <center> <img src="img/404.jpg" width="290px" height="400px" style="margin-top: 50px"></center>
        </div>
        
        <div class="col-sm-4" style="margin-top: 70px"></br>
</br></br>
        <center><h1> 4 0 4 </h1></center>
        <hr>
        <a href="login.php"><button type="button" class="btn btn-primary btn-block" width="50%">GO BACK</button></a>
        </div>
        </div>

        <div class="col-sm-2"></div>       
    </div>
</body>
</html>