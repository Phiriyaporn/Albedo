<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Albedo_Project</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="css/css.css">
    </head>
	<body>
		<nav class="navbar navbar-fixed-top navbar-inverse">
	        <div class="container-fluid">
	  </nav>
		<div class="container mainContainer">
			<center>
			</br></br>
				<!-- <img src="img/logo.jpg" style="margin-top: 20px"> -->
                <h1 style="margin-top: 40px">Albedo Repairing System</h1>
                <hr>
		    </center>
			    </div>
			</div> 
		    <div class="row">
		      <div class="col-sm-4 col-sm-offset-4">
		        <form method="POST" action="loginAction.php"> 
		          <div class="form-group">
		          	<input type="text" id="username" name="username" class="form-control" placeholder="Enter Username">
		          </div>

		          <div class="form-group">
		          	<input type="password" id="password" name="password" class="form-control" placeholder="Password">
		          </div>

		          <div class="form-group">
		          		<button type="submit" class="col-sm-12 btn btn-primary">Login</button>
		          </div>
		        </form>

		      </div>
		    </div>
		    <br>
		    <br>
		    <hr>
		    <footer> <center> &copy;ALBEDO PROJECT</center></footer>
	  	</div>
	</body>
</html>